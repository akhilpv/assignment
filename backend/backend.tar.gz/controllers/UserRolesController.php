<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

use common\models\AdminUsers;
use common\models\AdminRoles;
use common\models\AdminRolePermissions;

use yii\data\Pagination; 
use yii\helpers\Url;
use yii\helpers\ArrayHelper;

const REDIRECT_INDEX = 'user-roles/index';
const MSG_ROLEDELETE   = 'roleDelete';

class UserRolesController extends \yii\web\Controller
{
   public $hideRoleList = array('Super Admin');
   public $repoArray = array();
   public function behaviors()
    {
		
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    
                    [
                        ACTIONS => ['index','create','update','delete','privileges','update-privileges'],
                        'allow' => true,
                        ROLES => ['@'],
                    ],
                ],
            ],
           
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            ERROR => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
	}
	/**
	 * Display User Roles Page
	 */
    public function actionIndex($search='',$status=''){
		$search = trim($search);
		$this->view->title = "User Roles";
		$filterDesc = "";
		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'view');				
		$query = AdminRoles::find()->where([NOT_IN,ROLE_NAME,$this->hideRoleList])
							  ->orderBy("id DESC");
		if($search !=""){
			$query->andFilterWhere(['or',['like', ROLE_NAME, $search]]);
			$filterDesc .= $filterDesc == "" ? " : ".$search : " | ".$search;
		}					  
		if($status !=""){
			$query->andWhere(['status' => $status]);
			$filterDesc .= $filterDesc == "" ? " : ".$status : " | ".$status;
		}	  
		$countQuery = clone $query;
		$pages = new Pagination(['totalCount' => $countQuery->count(),'pageSize'=>Yii::$app->params['pageLimit']]);
		
		$posts = $query->offset($pages->offset)
			->limit(Yii::$app->params['pageLimit'])
			->all();

		return $this->render('index', [
			 'posts' => $posts,
			 'pages' => $pages,
			 'filterDesc' => $filterDesc
		]);
	}
	/**
	 *Create User Role Page 
	 * view form and add Role
	 */
	public function actionCreate(){
		$this->view->title = "Add User Roles";
		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'add');
		
		$model = new AdminRoles;
		$current_user = Yii::$app->user->getId();		
		$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));
		$model->created_on = date(DATETIME);
        $model->created_by = Yii::$app->user->getId();
        $model->created_ip = Yii::$app->getRequest()->getUserIP();
        $model->modified_on = date(DATETIME);
        $model->modified_by = Yii::$app->user->getId();
        $model->modified_ip = Yii::$app->getRequest()->getUserIP();	
		if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->saveRole()) {		
			Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'roleCreate',[NAME=>$model->role_name]));
				return $this->redirect($returnUrl);		
		}
		
		return $this->render('form',[MODEL=>$model]);
	}
	/**
	 * update User Role
	 * Param Integer @Id  
	 * */
    public function actionUpdate($id =0){

		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'edit');
		$current_user = Yii::$app->user->getId();		
        $returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	 
		$model= AdminRoles::find()->where(['Id' => $id])
							 ->andWhere([NOT_IN,ROLE_NAME,$this->hideRoleList])
							 ->one();
		if(!empty($model)){
			if ($model->load(Yii::$app->request->post())) {				
				$model->modified_on = date(DATETIME);
				$model->modified_by = $current_user;
				$model->modified_ip = Yii::$app->getRequest()->getUserIP();				
				if($model->saveRole()){
					Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'roleUpdate',[NAME=>$model->role_name]));
				return $this->redirect($returnUrl);		
				}
				
			}
		
			return $this->render('form',[MODEL=>$model]);
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_DATA_DOES_NOT_EXIST);			
				return $this->redirect($returnUrl);
		}					  

	}
	/**
	 * Delete User Role
	 * Param Integer @Id  
	  */
	public function actionDelete($id = 0){
		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'delete');
		$current_user = Yii::$app->user->getId();		
        $returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	 
		$model= AdminRoles::find()->where(['Id' => $id])
							 ->andWhere([NOT_IN,ROLE_NAME,$this->hideRoleList])
							 ->one();
		if(!empty($model)){
			$role_name = $model->role_name;			
			if(!empty($model->adminUsers)){
				Yii::$app->session->setFlash('error', 'The selected user role assigned to some admin users');
			}else if(!empty($model->adminRolePermissions)){
				//Delete Assingned Permissions for the role
				$rolePermission =  AdminRolePermissions::findOne([ROLE_ID=>$id]);
				$rolePermission->delete();
				Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,MSG_ROLEDELETE,[NAME=>$role_name]));
				$model->delete();
			} else {
				Yii::$app->session->setFlash(SUCCESS,Yii::t(USER_ALERETS,MSG_ROLEDELETE,[NAME=>$role_name]));
				$model->delete();
			}
		
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_DATA_DOES_NOT_EXIST);
		}
		
			return $this->redirect($returnUrl);
							 
	}
	/**
	 * View Previleges Of role
	 *  
	  */
	public function actionPrivileges($id = 0){
		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'view');
  
		$current_user = Yii::$app->user->getId();		
		$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	 
		$role= AdminRoles::find()->where(['Id' => $id])
							 ->andWhere([NOT_IN,ROLE_NAME,$this->hideRoleList])
							 ->one();
		if(!empty($role)){
			$model = AdminRolePermissions::find()->where([ROLE_ID => $role->id])->one();
            empty($model) ? $model = new AdminRolePermissions : "";
            $model->role_id = $role->id;
            $actions = $this->getRoleActions();
			
			
			return $this->render("viewPermission", [ACTIONS=>$actions, MODEL=>$model, 'role'=>$role,'current_user'=>$current_user]);
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_DATA_DOES_NOT_EXIST);
				return $this->redirect($returnUrl);
		}
	}
	/**
	 * Update Role Previlages
	 */
	public function actionUpdatePrivileges($id = 0){

		Yii::$app->permissions->isAllowed(MANAGE_USER_ROLES, 'edit');      
		$current_user = Yii::$app->user->getId();		
        $returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX])); 
		$role= AdminRoles::find()->where(['Id' => $id])
							 ->andWhere([NOT_IN,ROLE_NAME,$this->hideRoleList])
							 ->one();
		if(!empty($role)){
			$model = AdminRolePermissions::find()->where([ROLE_ID => $role->id])->one();
            if(empty($model)){
				 $model = new AdminRolePermissions;
				 $model->created_on = date(DATETIME);
				 $model->created_by = Yii::$app->user->getId();
				 $model->created_ip = Yii::$app->getRequest()->getUserIP();				 
				 $model->status = "Active";				
			}
			$model->role_id = $role->id;
			if (Yii::$app->request->post()) {		
				$model->modified_on = date(DATETIME);
				$model->modified_by = Yii::$app->user->getId();
				$model->modified_ip = Yii::$app->getRequest()->getUserIP();	
				$model->permissions = isset($_POST['RolePermissions']['permissions']) ? json_encode($_POST['RolePermissions']['permissions']) : "";
				if($model->updateRolePermissions()){
					Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'privileges'));
					return $this->redirect($returnUrl);
				}
			}
			
			$actions = $this->getRoleActions();
			return $this->render("formPrivileges", [ACTIONS=>$actions, MODEL=>$model, 'role'=>$role,'current_user'=>$current_user]);
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_DATA_DOES_NOT_EXIST);
			return $this->redirect($returnUrl);
			
		}
	}
	
	public function getRoleActions() {		
        return Yii::$app->permissions->AdminPermitions();
	}
}
