<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use linslin\yii2\curl;


use yii\web\UnauthorizedHttpException;

use backend\models\PasswordResetRequestForm;
use backend\models\PasswordOtpRequestForm;
use backend\models\LoginForm;

use common\models\NewTicket; //for test

use common\models\AdminUsers;

/**
 * Site controller
 */
const REDIRECT_INDEX = 'site/index';
class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */

    public function behaviors()
    {
        $this->layout = 'main';
        return [
            'access' => [
                CONST_CLASS => AccessControl::className(),
                'rules' => [
                    [
                        ACTIONS => ['login',ERROR],
                        'allow' => true,
                    ],
                    [
                        ACTIONS => ['logout','index','unautherized','new-ticket'
                                    ],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                CONST_CLASS => VerbFilter::className(),
                ACTIONS => [
                    'logout' => ['post','get'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                CONST_CLASS => 'yii\web\ErrorAction',
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
     
        return $this->render('index');
    }

    public function actionNewTicket()
    {
        $model = new NewTicket();
        $curl = new curl\Curl();
        $response = $curl->setGetParams([
            'Authorization'=>'9446933330c7f886fbdf16782906a9e0',
            'orgId'=>'60001280952',
        ])
         ->get('https://desk.zoho.in/api/v1/departments');
         
        return $this->render('new-ticket',compact('model'));
    }
    
    /**
     * Login action.
     *
     * @return string
     */
    public function actionLogin()
    {
        $this->layout = LOGIN_MAIN;
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        $model->password = '';
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            
                    return $this->goBack();
        } else {
          
                return $this->render('login', [
                    MODEL => $model,
                ]);
           
        }
    }

    /**
     * Logout action.
     *
     * @return string
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }
     
   
}
