<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

use common\models\AdminUsers;
use common\models\AdminRoles;
use common\models\AdminRolePermissions;


use yii\data\Pagination; 
use yii\helpers\Url;

//constant variables

const ADMIN_ROLES_NAME ='admin_roles.role_name';
const REDIRECT_INDEX = 'admin-users/index';
class AdminUsersController extends \yii\web\Controller
{
	public $hideRoleList = array('Super Admin');
	public $repoArray = array();
	
    public function behaviors()
    {
		
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    
                    [
                        'actions' => ['index','create','update','delete','change-password'],
                        'allow' => true,
                         ROLES => ['@'],
                    ],
                ],
            ],
           
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            ERROR => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }
	
	/**
	 * Displays Admin Users 
	 */
    public function actionIndex($search="",$role='',$status=""){	
		
		Yii::$app->permissions->isAllowed(MANAGE_USER, 'view');
        $filterDesc = "";
        $search = trim($search);
		$query = AdminUsers::find()->joinWith(['role'])
								   ->where([NOT_IN,ADMIN_ROLES_NAME,$this->hideRoleList])
								   ->orderBy("id DESC");
		if($search !=""){
			$query->andFilterWhere(['or',['like', ADMIN_ROLES_NAME, $search],['like', 'name', $search]]);
			$filterDesc .= $filterDesc == "" ? " : ".$search : " | ".$search;
		}					  
		if($status !=""){
			$query->andWhere(['admin_users.status' => $status]);
			$filterDesc .= $filterDesc == "" ? " : ".$status : " | ".$status;
		}	
		if($role !=""){
			$query->andWhere([ADMIN_ROLES_NAME => $role]);
			$filterDesc .= $filterDesc == "" ? " : ".$role : " | ".$role;
		}			
		$rolesArr = AdminRoles::getRolesHideList($this->hideRoleList);		  
		$countQuery = clone $query;
		$pages = new Pagination(['totalCount' => $countQuery->count(),'pageSize'=>Yii::$app->params['pageLimit']]);
		
		$posts = $query->offset($pages->offset)
			->limit(Yii::$app->params['pageLimit'])
			->all();

		return $this->render('index', [
			 'posts' => $posts,
			 'pages' => $pages,
			 'rolesArr' =>$rolesArr,
			 'filterDesc' => $filterDesc
		]);
	}
	/**
	 * Create Admin Users
	 */
	public function actionCreate(){			
		Yii::$app->permissions->isAllowed(MANAGE_USER, 'add');		
		$current_user = Yii::$app->user->getId();	
		$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	
			
		$model   =  new AdminUsers();
		$model->scenario = 'add__update_admin_user';
        if ($model->load(Yii::$app->request->post()) ) {
			$model->created_on = date(DATETIME);
			$model->created_ip = Yii::$app->getRequest()->getUserIP();
			$model->created_by = $current_user;
			$model->modified_on = date(DATETIME);
			$model->modified_ip = Yii::$app->getRequest()->getUserIP();
			$model->modified_by = $current_user;
			
			if($model->validate() && $model->createAdminUser()){
				Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'userCreate',[NAME=>$model->name]));
				 return $this->redirect($returnUrl);
			}
		}        
        $roles = AdminRoles::getRolesHideList($this->hideRoleList);
        return $this->render('form',[MODEL=>$model,ROLES=>$roles]);
	}
	/**
	 * Update Admin User
	 */
	public function actionUpdate($id = 0){

		Yii::$app->permissions->isAllowed(MANAGE_USER, 'edit');		
        $current_user = Yii::$app->user->getId();		
		$returnUrl    = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	

		$model= AdminUsers::find()->where(['id'=>$id,'user_type'=>'Admin'])->one();
		if(!empty($model)){
			$model->scenario = 'add__update_admin_user';
			if ($model->load(Yii::$app->request->post())) {
				$model->modified_on = date(DATETIME);
				$model->modified_ip = Yii::$app->getRequest()->getUserIP();
				if($model->updateAdminUser()){
					Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'userUpdate',[NAME=>$model->name]));
					return $this->redirect($returnUrl);
				}
			}		
			$roles = AdminRoles::getRolesHideList($this->hideRoleList);
			return $this->render('form',[MODEL=>$model,ROLES =>$roles]);
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_USER_DOES_NOT_EXIST);
			return $this->redirect($returnUrl);
		}					 
	}
	/**
	 * Delete Admin User
	 */
	public function actionDelete($id) {
		
		Yii::$app->permissions->isAllowed(MANAGE_USER, 'delete');		
        $current_user = Yii::$app->user->getId();		
		$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	
		
        $model= AdminUsers::find()->joinWith(['role'])
							 ->where([NOT_IN,ADMIN_ROLES_NAME,$this->hideRoleList])
							 ->andWhere(['admin_users.id'=>$id,'user_type'=>'Admin'])
							 ->one();
		if(!empty($model)){
			$model->delete();
			Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'userDelete',[NAME=>$model->name]));
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_USER_DOES_NOT_EXIST);
		}
		return $this->redirect($returnUrl);
	}
	/**
	 * Change Admin User Password
	 */
	public function actionChangePassword($id = 0) {
		Yii::$app->permissions->isAllowed(MANAGE_USER, 'edit');		
        $current_user = Yii::$app->user->getId();		
		$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));	
		
        $model= AdminUsers::find()->joinWith(['role'])
							 ->where([NOT_IN,ADMIN_ROLES_NAME,$this->hideRoleList])
							 ->andWhere(['admin_users.id'=>$id,'user_type'=>'Admin'])
							 ->one();
		if(!empty($model)){
			$model->modified_on = date(DATETIME);
			$model->modified_ip = Yii::$app->getRequest()->getUserIP();	
			$model->scenario ='update_user_pswd';
			if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->changePassword()) {
				Yii::$app->session->setFlash(SUCCESS, Yii::t(USER_ALERETS,'changeuserpswd',[NAME=>$model->name]));
					return $this->redirect($returnUrl);
			} 
			return $this->render('form-change-password',[MODEL=>$model]);
		}else{
			Yii::$app->session->setFlash(ERROR, SELECTED_USER_DOES_NOT_EXIST);
			return $this->redirect($returnUrl);
		}	
	}
		
}
