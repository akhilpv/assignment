<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\PasswordOtpResetRequestForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

$this->title = 'Forgot Password';
CONST LOGIN_TEMPLATE = '<div class="form-group has-feedback">{input}{error}{hint}
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span></div>';
$imageURL = Url::base(true).Yii::getAlias('@imagePath').'/';
?>
<div class="login-box-body">
    
     <!-- Alert Message -->
     <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
    <!-- //Alert Message -->
     <p class="login-box-msg">
     <img src="<?=$imageURL?>logo.png"  widht="100" height="90"><br>
     Change Password</p>
    <?php

         $form = ActiveForm::begin(['id' => 'password-otp-form']); 

        echo $form->field($model, 'reset_otp', [TEMPLATE => LOGIN_TEMPLATE])
                ->textInput([AUTOFOCUS => true,PLACEHOLDER=>'Enter OTP',CONST_CLASS=>FORMCONTROL]); 

        echo $form->field($model, 'password', [TEMPLATE => LOGIN_TEMPLATE])
                ->passwordInput([AUTOFOCUS => true,PLACEHOLDER=>'Password',CONST_CLASS=>FORMCONTROL]); 

        echo $form->field($model, 'confirm_password', [TEMPLATE => LOGIN_TEMPLATE])
                ->passwordInput([AUTOFOCUS => true,PLACEHOLDER=>'Confirm Password',CONST_CLASS=>FORMCONTROL]);
    ?>
    <div class="row">
        <div class="col-xs-8">
        <a href="<?=Url::to(['site/request-password-reset'])?>" class="pt-1 d-block">Back</a>
        </div>
    
        <div class="col-xs-4">
            <div class="btn-group">
                <?= Html::submitButton('Submit', [CONST_CLASS => 'btn btn-primary btn-block btn-flat', 'name' => 'login-button']) ?>
            </div>
        </div>
    </div>
    <?php 
    ActiveForm::end();
    ?>
</div>