<?php
/* @var $this yii\web\View */

$this->title = 'My Yii Application';
$this->title = 'Profile';
$this->params['breadcrumbs'][] = $this->title;
?>
<section class="content-header">
    <h1>
    unautherized
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
    
</section>      
    
<!-- Main content -->
<section class="content">
unautherized
</section>