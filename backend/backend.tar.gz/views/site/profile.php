<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\helpers\Url;
$this->title = 'Profile';
Yii::$app->view->params['head'] = 'Profile';
$this->params['breadcrumbs'][] = $this->title;
$clear_url = Url::to(['site/index']);
?>     
<!-- Main content -->
<section class="content">
<div class="row">
    <div class="col-md-12">
        <div class="box bt-0">
            <!-- /.box-header -->
            <div class="box-body p-0">
                <div class="clearfix mb-1">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#">Profile</a></li>
                            <li><a href="<?=Url::to(['site/change-password'])?>">Change Password</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clearfix"></div>
                    <div class="clearfix pl-2 pr-2">
                      <!-- Alert Message -->
                        <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
                        <!-- //Alert Message -->
                    <table class="table table-bordered table-hover">
                        <tbody>
                            <tr>
                                <td><b>Name</b></td>
                                <td><?=Yii::$app->user->identity->name?></td>
                            </tr> 
                            <tr>
                                <td><b>Email</b></td>
                                <td><?=Yii::$app->user->identity->email?></td>
                            </tr> 
                            <tr>
                                <td><b>Mobile</b></td>
                                <td><?=Yii::$app->user->identity->mobile?></td>
                            </tr>                
                        </tbody>
                    </table>
                    <div class="clearfix" style='padding: 0 0 20px 0;'>
                     <a href="<?= $clear_url ?>" class="btn btn-default pull-left ">Back</a>
                     <?= Html::a('Edit', ['site/edit-profile'], ['class'=>'btn btn-primary  pull-left ml-1']) ?>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- //Main content -->