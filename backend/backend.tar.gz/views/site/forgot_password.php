<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

$this->title = 'Forgot Password';
CONST LOGIN_TEMPLATE = '<div class="form-group has-feedback">{input}{error}{hint}
                        <span class="glyphicon glyphicon-envelope form-control-feedback"></span></div>';
$imageURL = Url::base(true).Yii::getAlias('@imagePath').'/';
?>
<div class="login-box-body">
  
    <p class="login-box-msg"> <img src="<?=$imageURL?>logo.png"  widht="100" height="90">
    <br>
     Forgot Password
    </p>
     <!-- Alert Message -->
     <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
    <!-- //Alert Message -->
    <?php 
        $form = ActiveForm::begin(['id' => 'change-password-form']); 

       echo  $form->field($model, 'email', ['template' => LOGIN_TEMPLATE])
                ->textInput(['autofocus' => true,'placeholder'=>'Enter Email Address','class'=>'form-control']);
    ?>
    <div class="row">

        <div class="col-xs-2">
            <a href="<?=Url::to(['site/login'])?>" class="pt-1 d-block"><span>Back</span></a>
        </div>   

        <div class="col-xs-5"></div> 

        <div class="col-xs-5">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary btn-block btn-flat', 'name' => 'forgot-button']) ?>
        </div>

    </div>
    <?php ActiveForm::end(); ?>
</div>