<?php
/* @var $this yii\web\View */
use yii\helpers\Url;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'User | Change Password';
Yii::$app->view->params['head'] = 'User';
$this->params['breadcrumbs'][] =  ['label' => 'Profile', 'url' => ['site/profile']];
$this->params['breadcrumbs'][] =  'Change Password';

const FORM_TEMPLATE  ='<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label></div><div class="col-sm-6">{input}{error}{hint}</div></div>';
$clear_url = Url::to(["site/profile"]);
?>    
    
<!-- Main content -->
<section class="content">
<div class="row">
    <div class="col-md-12">
        <div class="box bt-0">
            <!-- /.box-header -->
            <div class="box-body p-0">
                <div class="clearfix mb-1">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li><a href="<?=Url::to(['site/profile'])?>">Profile</a></li>
                            <li  class="active"><a href="<?=Url::to(['site/change-password'])?>">Change Password</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clearfix"></div>
                    <div class="clearfix pl-2 pr-2">
         <!-- Alert Message -->
         <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
            <!-- //Alert Message -->
    <!-- form start -->
    <?php $form =ActiveForm::begin(['id'=>'change-password'])?>
        <div class="box-body">
            <?= $form->field($model, 'old_password', [
                'template' => FORM_TEMPLATE
            ])->textInput(['autofocus' => true,'placeholder'=>'Old Password','class'=>'form-control']); ?>

            <?= $form->field($model, 'password', [
                'template' => FORM_TEMPLATE
            ])->passwordInput(['autofocus' => true,'placeholder'=>'New Password','class'=>'form-control']); ?>

            <?= $form->field($model, 'confirm_password', [
                'template' => FORM_TEMPLATE
            ])->passwordInput(['autofocus' => true,'placeholder'=>'New Password','class'=>'form-control']); ?>
            <div class="row form-group">
                <div class="col-sm-3 text-right pt-1">&nbsp;</div>
                <div class="col-sm-6 clearfix">
                    <?= Html::submitButton('Save', ['class' => 'btn btn-primary pull-left', 'name' => 'change-password-button']) ?>
                    <a href="<?= $clear_url ?>" class="btn btn-default pull-left ml-1">Back</a>
                </div>
            </div>
        </div>
  <?php ActiveForm::end(); ?>
 <!-- form End -->
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- //Main content -->


