<?php
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
$this->title = 'Profile | Update';
const FORM_TEMPLATE  ='<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label></div><div class="col-sm-6">{input}{error}{hint}</div></div>';
$current_user = Yii::$app->user->getId();		
$cancel_url    =["admin-users/index"];

$this->params['head'] = 'Profile'; //Page Head
//Breadcrumbs
$this->params['breadcrumbs'][] =['label'=>'Profile','url'=>['site/profile']];
$this->params['breadcrumbs'][] = 'Update';
?>

<!-- Main content -->
<section class="content">
<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Update</h3>
            </div> 
            <!-- Alert Message -->
             <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
            <!-- //Alert Message -->

            <!-- form start -->
            <div class="box-body">
                <?php 
                    
                    $form =ActiveForm::begin(['id'=>'update-profile']);
            
                    echo $form->field($model, 'name', ['template' => FORM_TEMPLATE])
                        ->textInput(['autofocus' => true,'placeholder'=>'Name',CONST_CLASS=>FORMCONTROL]); 

                    echo $form->field($model, 'mobile', ['template' => FORM_TEMPLATE])
                            ->textInput(['autofocus' => true,'placeholder'=>'Mobile',CONST_CLASS=>FORMCONTROL]); 
                ?>
                    <div class="row form-group">
                        <div class="col-sm-3 text-right pt-1">&nbsp;</div>
                        <div class="col-sm-6 clearfix">
                            <?= Html::submitButton('Save', ['class' => 'btn btn-primary pull-left', 'name' => 'update-profile-button']) ?>
                            <a href="<?=Url::to(['site/profile'])?>" class="btn btn-default pull-left ml-1">Cancel</a>
                        </div>
                    </div>
                <?php ActiveForm::end(); ?>
            </div>
            <!-- form End -->
        </div>
    </div>
</div>
</section>
<!-- //Main content -->