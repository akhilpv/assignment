<?php
use yii\helpers\Url;
use yii\widgets\LinkPager; 
use  yii\web\View; 
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'User Roles | Privileges';
Yii::$app->view->params['head'] = 'User Management';
$this->params['breadcrumbs'][] =  ['label' => 'User Roles', 'url' => ['user-roles/index']];
$this->params['breadcrumbs'][] =  'Privileges';

$current_user = Yii::$app->user->getId();
if (isset(Yii::$app->session['userView' . $current_user . 'returnURL'])) {
	$cancel_url = Yii::$app->session['userView' . $current_user . 'returnURL'];
} else {
	$cancel_url = Url::to(["user-roles/privileges",'id'=>$role->id]);
}

$clear_url = Url::to(["user-roles/index"]);
?>

<section class="content">
   <div class="row">    
     	<div class="col-md-12">
        	<div class="box">
       			<div class="box-header with-border">
            		<h3 class="box-title">Update <?=$role->role_name?>  Privileges</h3>
        		</div>
<?php if (Yii::$app->session->hasFlash('success')): ?> 
	<div class="alert alert-success alert-dismissable">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<?= Yii::$app->session->getFlash('success') ?>
	</div>
<?php endif; ?>
<?php if (Yii::$app->session->hasFlash('error')): ?>
 <div class="alert alert-danger alert-dismissable">
     <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> 
     <?= Yii::$app->session->getFlash('error') ?> 
 </div>
<?php endif; ?>

<div class="box-body">
	<table class="table table-bordered table-hover">
		<tbody>
			<tr>
				<th>Privilege Section</th>
				<th>Actions</th>
			</tr>
	<?php
	$form = ActiveForm::begin(['id' => 'user-privileges','options'=>['class'=>'form-horizontal form-material','enctype' => 'multipart/form-data']]); ?>
		<input class="m-r-5" checked="" type="hidden" name="RolePermissions[permissions][Manage Dashboard][]" value="view">		
			<?php
				$permissions = !empty($model) ? json_decode($model->permissions,true) : array();
				$i = $cnt= 0;
			foreach($actions as $ob=>$action){
				$act = [];
					foreach($action as $key){
						$act[$key]=$key;
					}	
				isset($permissions[$ob]) ? $preSelectedActions = $permissions[$ob] : $preSelectedActions = "";	
	?>	
			<tr>																			
				<td><?php echo ucfirst($ob);?></td>
				<td>
					<?php	
						$modelV = "RolePermissions[permissions][$ob][]";
						echo Html::checkBoxList($modelV,$preSelectedActions, $act, ['id'=>"role-section-".$i++,'class'=>'role-section','value'=>$action,'labelOptions'=>['class'=>'user-role-check-box-label'],
							'item'=>function ($index, $label, $name, $checked, $value){
									$checked = $checked ? 'checked' : '';
							return '<div class="col-md-4 col-sm-6 col-xs-12">
									<span class="checkbox-user-roles">
													<input    '.$checked.' id="'.$name.$label.'" class="css-checkbox" type="checkbox"  name="'.$name.'" value="'.$value.'" /><label for="'.$name.$label.'" class="css-label radGroup1">'.$label.'
												</label>
										</span>
											</div>';
								}	
										
						]);
					?>
				</td>
				
			</tr>
		<?php } ?>	
			<tr>
				<td></td>
				<td>
					<div class="form-actions clearfix">
						<div class="col-sm-12">
						<?= Html::submitButton('Save', ['class' => 'btn btn-primary pull-left', 'name' => 'update-privileges']) ?>
						<a href="<?=$cancel_url?>" class="btn btn-default pull-left ml-1">Cancel</a>
						</div>
					</div>
				</td>
			</tr>
			<?php ActiveForm::end(); ?>	

		</tbody>
	</table>
 </div>
</div>
</section>
<?php
$this->registerJs(
    "$('.role-section :checkbox').change(function() {
	 if($(this).is(':checked')) {
			if(this.value != 'view'){
				selectId = $(this).closest('.role-section').attr('id');		
				$('#'+selectId+' input[type=checkbox]').each(function() {
					if(this.value =='view' && !$(this).is(':checked')){
						$(this).prop('checked', true);
					}
				});				
			}
	 }else{
		if(this.value == 'view'){
			selectId = $(this).closest('.role-section').attr('id');		
			$('#'+selectId+' input[type=checkbox]').each(function() {				
					$(this).prop('checked', false);				
			});
		}
	 }
}); 
    ",
    View::POS_READY,
    'delete-record-handler'
);
?>
