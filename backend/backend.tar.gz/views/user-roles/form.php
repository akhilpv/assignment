<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;

use yii\widgets\ActiveForm;

$this->title = 'User Roles | Add';
Yii::$app->view->params['head'] = 'User Management';
$this->params[BREADCRUMBS][] =  ['label' => 'Admin User Management', 'url' => 'JavaScript:void(0)'];
$this->params[BREADCRUMBS][] =  ['label' => 'User Roles', 'url' => ['user-roles/index']];
$this->params[BREADCRUMBS][] =  $model->isNewRecord ? 'Add' : 'Update';
const FORM_TEMPLATE  ='<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label>
                        </div><div class="col-sm-6">{input}{error}{hint}</div></div>'; 
$cancel_url = Url::to(['user-roles/index']);

?>  
    
    <section class="content">
    <div class="row">
        <div class="col-sm-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title"><?=$model->isNewRecord ? 'Add' : 'Update'?> Role</h3>
                </div> 
                    <!-- Alert Message -->
                    <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
                    <!-- //Alert Message -->
                <!-- form start -->
                <div class="box-body">
                    <?php 
                        $form =     ActiveForm::begin(['id'=>'update-profile']);

                        echo $form->field($model, 'role_name', ['template' => FORM_TEMPLATE])
                            ->textInput(['autofocus' => true,'placeholder'=>'Name','class'=>'form-control']); 
                        
                            $model->status == "" ? $model->status = ACTIVE : 0;
                    
                        echo $form->field($model, 'status',['template' => FORM_TEMPLATE,])
                            ->dropDownList([ACTIVE=>ACTIVE,'Inactive'=>'Inactive'],['prompt'=>'Select',]);	
                    ?>
                    
                    <div class="row form-group">
                        <div class="col-sm-3 text-right pt-1">&nbsp;</div>
                        <div class="col-sm-6 clearfix">
                            <?= Html::submitButton('Save', ['class' => 'btn btn-primary pull-left', 'name' => 'update-profile-button']) ?>
                            <a href="<?=$cancel_url?>" class="btn btn-default pull-left ml-1">Cancel</a>
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>  
                <!-- form End -->
                </div>
            </div>
        </div>
</section>