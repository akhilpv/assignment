<?php
use yii\helpers\Url;
use yii\widgets\LinkPager; 
use  yii\web\View; 
use yii\bootstrap\ActiveForm;


$this->title = 'Admin User Management | User Roles';
Yii::$app->view->params['head'] = 'User Management';
$this->params['breadcrumbs'][] =  ['label' => 'Admin User Management', 'url' => 'JavaScript:void(0)'];
$this->params['breadcrumbs'][] =  'User Role';

$clear_url = Url::to(["user-roles/index"]);
?>
<section class="content">
          <div class="row">    
<div class="col-md-12">
        <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">User Role <small><?=$pages->totalCount?>  record found <?=$filterDesc?></small></h3>
            <div class="box-tools">
            <div class="clearfix pull-right">
<?php
if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage User Roles', 'add')){
    ?>
    <a href="<?=Url::to(['user-roles/create'])?>" class="btn btn-primary btn-sm pull-left" title="Add"><i class="fa fa-plus"></i></a>
   <?php
}
?>
                <a data-toggle="collapse" href="#collapseExample" aria-expanded="true" aria-controls="collapseExample" class="btn btn-primary btn-sm pull-left ml-1"><i class="fa fa-filter"> &nbsp;Filter</i></a>
            </div>
            </div>
        </div>
       <?php  $form = ActiveForm::begin(['id'=>'filter-form','action'=>Url::to(['user-roles/index']),'method'=>'GET']); ?>
        <div class="col-sm-12">
            <br>
            <div class="collapse" id="collapseExample" aria-expanded="true" style="">
            <div class="well">
                <div class="row">
                <div class="col-sm-3">
                <input type="text" id="search" name="search" class="form-control" placeholder="Type here" value="<?=@$_GET['search']?>">
                </div>
                <div class="col-sm-3">
                    <select class="custom-select font-15 m-l-0 select2-container-multi form-control" name="status" id="status">
                    <option value="">Select Status</option>
                    <option value="Active" <?=@$_GET['status'] == 'Active' ? "selected" : ''?>>Active</option>
                    <option value="Inactive" <?=@$_GET['status'] == 'Inactive' ? "selected" : ''?>>Inactive</option>
                    </select>
                </div>
                </div>
                <div class="row">
                <div class="col-sm-12"><br></div>
                <div class="col-sm-12">
                    <a href="<?=$clear_url?>" class="btn pull-right ml-1 bg-navy">Clear</a>
                    <button type="submit" class="btn btn-success pull-right">Submit</button>
                </div>
                </div>
            </div>
            </div>
        </div>
       <?php ActiveForm::end(); ?>

<?php 
    if (Yii::$app->session->hasFlash('success') || Yii::$app->session->hasFlash('error')){  
    $className =  (Yii::$app->session->hasFlash('success')) ? 'success' : 'danger';
?>
<div class="col-md-12">
 <div class="alert alert-<?=$className?> alert-dismissable">
     <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
     <?=(Yii::$app->session->hasFlash('success')) ? (Yii::$app->session->getFlash('success')) : (Yii::$app->session->getFlash('error'));  ?>
 </div>
</div>
    <?php } ?>

        <!-- /.box-header -->
        <div class="box-body">
            <table class="table table-bordered table-hover">
            <tbody>
            <tr>
			<th>#</th>
				<th>Role</th>
				<th>Status</th>
				<th>Privileges</th>
				<th>Action</th>
            </tr>
<?php
if(!empty($posts)){
    $count = $pages->getLimit() * $pages->getPage();	
    foreach ($posts as $data) {
    ?>	
        <tr>	
		<td style="vertical-align: middle;"><?=++$count?></td>								
		<td style="vertical-align: middle;"><?=$data->role_name?></td>
		<td style="vertical-align: middle;"><span class="label <?=$data->status=="Active" ? 'label-success' : 'label-warning'?>"><?=$data->status?></span></td>
		<td style="vertical-align: middle;"><a class="label label-success" href="<?=Url::to(['user-roles/privileges','id'=>$data->id])?>">View Privileges</a> </td>
		<td style="vertical-align: middle;">


			<?php
			if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage User Roles', 'edit')){ ?>	
				<a href="<?=Url::to(['user-roles/update','id'=>$data->id])?>"  class="btn bg-orange edit-btn" title="Edit">
					<i class="fa fa-pencil" aria-hidden="true"></i>
				</a>
			<?php
			}
			if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage User Roles', 'delete')){ ?>	

				<a href="<?=Url::to(['user-roles/delete','id'=>$data->id])?>" class="btn bg-maroon delete-action" title="Delete">
					<i class="fa fa-trash" aria-hidden="true"></i>
				</a>
			<?php
			}?>									
		</td>
	</tr>
<?php
    }
}else{ ?>	
        
        <tr>
            <td colspan="5" class="text-center">Sorry! No record found.</td>
        </tr>	
            
<?php
} ?>	
            </tbody></table>
        </div>
<!-- /.box-body -->
<!-- Pagination Start -->
<?php if($pages->totalCount > $pages->getLimit()){ ?>
<div class="row">
<div class="col-sm-12">
            <div  class="box-footer clearfix">
                    <?php
                    echo LinkPager::widget ( [
                            'id'=>'my-pager',
                            'pagination' => $pages ,
                            'activePageCssClass' => 'active' ,
                            'prevPageLabel' => "«" ,
                            'nextPageLabel' => "»" ,
                            'maxButtonCount' => 5 ,
                            'options' => [
                                'class' => 'pagination pagination-sm no-margin pull-right',
                            ]
                        ] );

                    ?>							
            </div>
</div>
</div>
<!-- /.row -->
<?php
}
?>
<!-- //Pagination End -->
</div>
        </div>
        <!-- /.box -->
        
        <!-- /.box -->
    </div>
</div>
<!-- Delete Model -->
<div id="confirm-delete-div" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body text-center">
                <h4>Confirm Delete</h4>
                <p class="margin-top-20">Do you want to delete?</p>
                <input type="hidden" id="modalRedirectUrl" />
            </div>
            <div class="clearfix text-center">
                <button type="button" class="btn btn-danger waves-effect mb-1 mr-1" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-success waves-effect mb-1" id="delete-confirm">Yes</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<div>
</section>
<?php
$this->registerJs(
    " $('.delete-action').on('click', function (event) {
			event.preventDefault();
            var url = this.href;           
            $('#modalRedirectUrl').val(url);           
            $('#confirm-delete-div').modal('show');           

        });
         $('#delete-confirm').on('click', function () {
            var id = $('#user_id').val();
            var url = $('#modalRedirectUrl').val();           
            window.location.href = url;
        });
         $('#filter-data').change(function() {
			 var status = this.value;
			var search = $('#search').val();
			var uri = '';
           
            uri += search == '' || search == null ? '' : 'search=' + search;
            uri += status == '' || status == null ? '' : (uri!='' ? '&status=' + status : 'status=' + status);
            
            window.location.href = '".Url::to(["user-roles/index"])."?' + uri;
		});",
    View::POS_READY,
    'delete-record-handler'
);
?>
