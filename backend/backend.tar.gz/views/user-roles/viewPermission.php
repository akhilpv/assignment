<?php
use yii\helpers\Url;
use yii\helpers\Html;
use  yii\web\View; 

$this->title = 'User Roles | Privileges';
Yii::$app->view->params['head'] = 'User Management';
$this->params['breadcrumbs'][] =  ['label' => 'User Roles', 'url' => ['user-roles/index']];
$this->params['breadcrumbs'][] =  'Privileges';

$clear_url = Url::to(["user-roles/index"]);
?>

<section class="content">
          <div class="row">    
<div class="col-md-12">
        <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?=$role->role_name?> - Privileges</h3>
            <div class="box-tools">
            <div class="clearfix pull-right">
<?php
if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage User Roles', 'add')){
    ?>
    <a href="<?=Url::to(['user-roles/update-privileges','id'=>$role->id])?>" class="btn btn-primary btn-sm pull-left ml-1">Update Privileges</a>
   <?php
}
?>
            </div>
            </div>
        </div>
       
        <?php if (Yii::$app->session->hasFlash('success')): ?>
 
 <div class="alert alert-success alert-dismissable">
     <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
     <?= Yii::$app->session->getFlash('success') ?>
 </div>
<?php endif; ?>
<?php if (Yii::$app->session->hasFlash('error')): ?>

 <div class="alert alert-danger alert-dismissable">
     <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> 
     <?= Yii::$app->session->getFlash('error') ?> 
 </div>
<?php endif; ?>
        <!-- /.box-header -->
        <div class="box-body">
            <table class="table table-bordered table-hover">
            <tbody>
            <tr>
			<th>Privilege Section</th>
				<th>Actions</th>
            </tr>
            <?php
							$permissions = !empty($model) ? json_decode($model->permissions,true) : array();
							foreach($actions as $ob=>$action){
									foreach($action as $key){
										$act[$key]=$key;
									}	
									isset($permissions[$ob]) ? $preSelectedActions = $permissions[$ob] : $preSelectedActions = "";	
								?>	
									<tr>																			
										<td><?php echo ucfirst($ob);?></td>
										<td>
											<span class="user-role-box">
											<?php
												foreach($action as $key){ ?>
													<div class='col-md-3 col-sm-6 col-xs-12'>
														<span class="checkbox-user-roles"> 
															<b>
															<?php
															if(!empty($preSelectedActions) && in_array($key,$preSelectedActions)){ ?>
																<i class="fa fa-check-circle text-success" aria-hidden="true"></i>
															<?php
															}else{?>
																<i class="fa fa-times-circle text-danger" aria-hidden="true"></i>
															<?php
															} ?> 
															</b>
															<label class="user-role-check-box-label">
																<?=$key?>
															</label>
														</span>
													</div>	
												<?php
												} ?>
											</span>
										</td>
										
									</tr>
							<?php
							}
							?>

            </tbody>
        </table>
        </div>
<!-- /.box-body -->
</div>
</section>
