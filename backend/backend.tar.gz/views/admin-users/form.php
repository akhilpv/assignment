<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;

use yii\widgets\ActiveForm;

$this->title = 'Admin User Management | Users';
Yii::$app->view->params['head'] = 'Admin Users';
$this->params[BREADCRUMBS][] =  ['label' => 'Admin User Management', 'url' => 'JavaScript:void(0)'];
$this->params[BREADCRUMBS][] =  ['label' => 'Users', 'url' => ['admin-users/index']];
$this->params[BREADCRUMBS][] =$model->isNewRecord ? 'Add' : 'Update';

const FORM_TEMPLATE  ='<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label></div><div class="col-sm-6">{input}{error}{hint}</div></div>';
const FIELD_PASSWORD = '<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label></div><div class="col-sm-6">{input}{error}{hint}</div><a title="Hide Password" id="change_eye" onclick="showPassword(this)" href="javascript:void(0)"><i class="fa fa-eye"></i></a><a style="margin-left:4px" onclick="generatePassword()" href="javascript:void(0)">Generate Password</a></div>';
const REDIRECT_INDEX = 'admin-users/index';

$cancel_url = Url::to(['admin-users/index']);
?>    
    
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-sm-12">
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?=$model->isNewRecord ? 'Add' : 'Update'?> User</h3>
        </div> 
         <!-- Alert Message -->
         <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
        <!-- //Alert Message -->
    <!-- form start -->
    <div class="box-body">
        <?php $form =ActiveForm::begin(['id'=>'update-profile']);
            
                echo $form->field($model, 'name', [TEMPLATE => FORM_TEMPLATE])
                        ->textInput([AUTOFOCUS => true,PLACEHOLDER=>'Name',CONST_CLASS=>FORMCONTROL]); 

                echo $form->field($model, 'email', [TEMPLATE => FORM_TEMPLATE])
                        ->textInput([AUTOFOCUS => true,PLACEHOLDER=>'Email',CONST_CLASS=>FORMCONTROL])
                        ->hint('Login credentials are send to this email address',[CONST_CLASS=>'text-aqua small']);

                echo $form->field($model, 'mobile', [TEMPLATE => FORM_TEMPLATE])
                        ->textInput([AUTOFOCUS => true,PLACEHOLDER=>'Mobile',CONST_CLASS=>FORMCONTROL]);

                $roles=ArrayHelper::map($roles,'id','role_name');
                
                echo $form->field($model, 'role_id',[TEMPLATE => FORM_TEMPLATE,])
                    ->dropDownList($roles,['prompt'=>'Select',]);		
                
            if ($model->isNewRecord) {

            echo  $form->field($model, 'password', [TEMPLATE => FIELD_PASSWORD])
                        ->passwordInput([AUTOFOCUS => true,PLACEHOLDER=>'Password',CONST_CLASS=>FORMCONTROL,'id'=>'user-password']);
            }
        
            $model->status == "" ? $model->status = ACTIVE : 0;
            
            echo $form->field($model, 'status',[TEMPLATE => FORM_TEMPLATE,])
                    ->dropDownList(['Active'=>'Active','Inactive'=>'Inactive'],['prompt'=>'Select',]);
        ?>
                <div class="row form-group">
                    <div class="col-sm-3 text-right pt-1">&nbsp;</div>
                    <div class="col-sm-6 clearfix">
                        <?= Html::submitButton('Save', [CONST_CLASS => 'btn btn-primary pull-left', 'name' => 'update-profile-button']) ?>
                        <a href="<?=$cancel_url?>" class="btn btn-default pull-left ml-1">Cancel</a>
                    </div>
                </div>
        <?php ActiveForm::end(); ?>
    </div>      
    
 <!-- form End -->
    </div>
</div>
</div>
</section>
<!-- //Main content -->
<script>
    function generatePassword() {
        event.preventDefault();
        psd = Math.random().toString(36).slice(-8);
        $("#user-password").val(psd);
        var x = document.getElementById("user-password");
        if (x.type === "password") {
            $('#change_eye').trigger('click');
        }
    }

    function showPassword(ev) {
        var x = document.getElementById("user-password");
        if (x.type === "password") {
            x.type = "text";
            $(ev).html("<i class='fa fa-eye'></i>");

            $(ev).attr('title', "Hide Password");
        } else {
            x.type = "password";
            $(ev).html("<i class='fa fa-eye-slash'></i>")
            $(ev).attr('title', "Show Password");
        }
    }
</script>