<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;

use yii\widgets\ActiveForm;

$this->title = 'User Update';
$this->params['head'] = 'Admin Users';
$this->params['breadcrumbs'][] =  ['label' => 'Admin User Management', 'url' => 'JavaScript:void(0)'];
$this->params['breadcrumbs'][] =  ['label' => 'Users', 'url' => ['admin-users/index']];
$this->params['breadcrumbs'][] = 'Change Password';
const REDIRECT_INDEX = 'admin-users/index';
const FORM_TEMPLATE  ='<div class="row form-group"><div class="col-sm-3 text-right pt-1"><label>{label}</label></div><div class="col-sm-6">{input}{error}{hint}</div></div>';

$current_user = Yii::$app->user->getId();
$returnUrl = Yii::$app->generalFunctions->returnUrl($current_user,Url::to([REDIRECT_INDEX]));
$cancel_url = Url::to($returnUrl);

	$model->password = '';
?>     
    
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-sm-12">
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Change Password</h3>
        </div> 
        <!-- Alert Message -->
            <?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
        <!-- //Alert Message -->
   
   <!-- form start -->
   <div class="box-body">
        <?php 
            $form =ActiveForm::begin(['id'=>'change-password','options'=>['autocomplete'=>'off']]);
            
            echo $form->field($model, 'password', ['template' => FORM_TEMPLATE])
                    ->passwordInput(['autofocus' => true,'placeholder'=>'New Password','class'=>'form-control']); 

            echo $form->field($model, 'confirm_password', ['template' => FORM_TEMPLATE])
                    ->passwordInput(['autofocus' => true,'placeholder'=>'Confirm Password','class'=>'form-control']); 
        ?>
            <div class="row form-group">
                <div class="col-sm-3 text-right pt-1">&nbsp;</div>
                <div class="col-sm-6 clearfix">
                    <?= Html::submitButton('Submit', ['class' => 'btn btn-primary pull-left', 'name' => 'change-password-button']) ?>
                    <a href="<?=$cancel_url?>" class="btn btn-default pull-left ml-1">Cancel</a>
                </div>
            </div>
        <?php ActiveForm::end(); ?>   
    </div>          
 <!-- form End -->
    </div>
</div>
</div>
</section>
<!-- //Main content -->