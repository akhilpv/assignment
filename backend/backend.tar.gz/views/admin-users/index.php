<?php
use yii\helpers\Url;
use yii\widgets\LinkPager; 
use  yii\web\View; 
use yii\bootstrap\ActiveForm;
$this->title = 'Admin User Management | Users';
Yii::$app->view->params['head'] = 'User Management';
$this->params['breadcrumbs'][] =  ['label' => 'Admin User Management', 'url' => 'Javascript:void(0)'];
$this->params['breadcrumbs'][] =  'Users';

$clear_url = Url::to(["admin-users/index"])
?>
<section class="content">
          <div class="row">    
<div class="col-md-12">
        <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Users <small><?=$pages->totalCount?>  record found <?=$filterDesc?></small></h3>
            <div class="box-tools">
            <div class="clearfix pull-right">
<?php
if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage Users', 'add')){
    ?>
    <a href="<?=Url::to(['admin-users/create'])?>" class="btn btn-primary btn-sm pull-left" title="Add"><i class="fa fa-plus"></i></a>
   <?php
}
?>
                <a data-toggle="collapse" href="#collapseExample" aria-expanded="true" aria-controls="collapseExample" class="btn btn-primary btn-sm pull-left ml-1"><i class="fa fa-filter"> &nbsp;Filter</i></a>
            </div>
            </div>
        </div>
        
        <div class="col-sm-12">
            <br>
           <?php ActiveForm::begin(['id'=>'filter-form','action'=>Url::to(['admin-users/index']),'method'=>'GET']); ?>
            <div class="collapse" id="collapseExample" aria-expanded="true" style="">
            <div class="well">
                <div class="row">
                <div class="col-sm-3">
                <input type="text" id="search" name="search" class="form-control" placeholder="Type here" value="<?=@$_GET['search']?>">
                </div>
                <div class="col-sm-3">
                    <select class="custom-select font-15 m-l-0 select2-container-multi form-control" name="role" id="role">
                    <option value="">Select Role</option>
                    <?php foreach($rolesArr as $roles) : ?>
                    <option value="<?=$roles->role_name?>" <?=@$_GET['role'] == $roles->role_name ? "selected" : ''?>><?=$roles->role_name?></option>
                    <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-sm-3">
                    <select class="custom-select font-15 m-l-0 select2-container-multi form-control" name="status" id="status">
                    <option value="">Select Status</option>
                    <option value="Active" <?=@$_GET['status'] == 'Active' ? "selected" : ''?>>Active</option>
                    <option value="Inactive" <?=@$_GET['status'] == 'Inactive' ? "selected" : ''?>>Inactive</option>
                    </select>
                </div>
                </div>
                <div class="row">
                <div class="col-sm-12"><br></div>
                <div class="col-sm-12">
                    <a href="<?=$clear_url?>" class="btn pull-right ml-1 bg-navy">Clear</a>
                    <button type="submit" class="btn btn-success pull-right">Submit</button>
                </div>
                </div>
            </div>
          <?php  ActiveForm::end(); ?>
            </div>
        </div>
       
<!-- Alert Message -->
<?=Yii::$app->controller->renderpartial('@app/views/layouts/_alert_message')?>
<!-- //Alert Message -->
        <!-- /.box-header -->
        <div class="box-body">
            <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th style="width: 10px">#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role </th>
                <th>Status</th>
                <th>Action</th>
            </tr>
<?php
if(!empty($posts)){
    $count = $pages->getLimit() * $pages->getPage();	
    foreach ($posts as $data) {
    ?>	
        <tr >
            <td style="vertical-align: middle;"><?=++$count ?></td>
            <td style="vertical-align: middle;">
            <?=$data->name?>
            </td>
            <td style="vertical-align: middle;">
            <?=$data->email?>
            </td>									
            <td style="vertical-align: middle;"><?=$data->role->role_name?></td>
            <td style="vertical-align: middle;"><span class="label <?=$data->status=="Active" ? 'label-success' : 'label-warning'?>"><?=$data->status?></span></td>
            <td style="vertical-align: middle;">
                <?php
                if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage Users', 'edit')){ ?>	
                    <a href="<?=Url::to(['admin-users/update','id'=>$data->id])?>" class="btn bg-orange" title="Edit">
                        <i class="fa fa-pencil" aria-hidden="true"></i>
                    </a>
                <?php
                }
                if (Yii::$app->user->getId() != $data->id && Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage Users', 'delete')){ ?>		
                    <a href="<?=Url::to(['admin-users/delete','id'=>$data->id])?>" class="btn bg-maroon delete-action" title="Delete">
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </a>
                <?php
                }
                if (Yii::$app->permissions->isActionAllowed(Yii::$app->user->getId(), 'Manage Users', 'edit')){ ?>	
                    <a href="<?=Url::to(['admin-users/change-password','id'=>$data->id])?>" class="btn bg-navy" title="Change Password"><i class="fa fa-lock" aria-hidden="true"></i></a>
                <?php
                }?>	
                                                    
            </td>
        </tr>
<?php
    }
}else{ ?>	
        
        <tr>
            <td colspan="6" class="text-center">Sorry! No record found.</td>
        </tr>	
            
<?php
} ?>	
            </tbody></table>
        </div>
<!-- /.box-body -->
<!-- Pagination Start -->
<?php if($pages->totalCount > $pages->getLimit()){ ?>
<div class="row">
<div class="col-sm-12">
            <div  class="box-footer clearfix">
                    <?php
                    echo LinkPager::widget ( [
                            'id'=>'my-pager',
                            'pagination' => $pages ,
                            'activePageCssClass' => 'active' ,
                            'prevPageLabel' => "«" ,
                            'nextPageLabel' => "»" ,
                            'maxButtonCount' => 5 ,
                            'options' => [
                                'class' => 'pagination pagination-sm no-margin pull-right',
                            ]
                        ] );

                    ?>							
            </div>
</div>
</div>
<!-- /.row -->
<?php
}
?>
<!-- //Pagination End -->
</div>
        </div>
        <!-- /.box -->
        
        <!-- /.box -->
</section>
<!-- Delete Model -->
<div id="confirm-delete-div" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body text-center">
                <h4>Confirm Delete</h4>
                <p class="margin-top-20">Do you want to delete?</p>
                <input type="hidden" id="modalRedirectUrl" />
            </div>
            <div class="clearfix text-center">
                <button type="button" class="btn btn-danger waves-effect mb-1 mr-1" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-success waves-effect mb-1" id="delete-confirm">Yes</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<?php
$this->registerJs(
    " $('.delete-action').on('click', function (event) {
			event.preventDefault();
            var url = this.href;           
            $('#modalRedirectUrl').val(url);           
            $('#confirm-delete-div').modal('show');           

        });
         $('#delete-confirm').on('click', function () {
            var id = $('#user_id').val();
            var url = $('#modalRedirectUrl').val();           
            window.location.href = url;
        });
         $('#filter-data').change(function() {
			 var status = this.value;
			var search = $('#search').val();
			var uri = '';
           
            uri += search == '' || search == null ? '' : 'search=' + search;
            uri += status == '' || status == null ? '' : (uri!='' ? '&status=' + status : 'status=' + status);
            
            window.location.href = '".Url::to(["user-roles/index"])."?' + uri;
		});",
    View::POS_READY,
    'delete-record-handler'
);
?>