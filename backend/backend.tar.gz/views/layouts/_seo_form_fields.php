<?php

    echo $form->field($model, 'seo_title', [TEMPLATE => FORM_TEMPLATE])
    ->textInput(['autofocus' => true,'placeholder'=>'Page Title',CONST_CLASS=>'form-control'])->label('Page Title');

    echo $form->field($model, 'seo_metatag', [TEMPLATE => FORM_TEMPLATE])
        ->textInput(['autofocus' => true,'placeholder'=>'Meta Tag',CONST_CLASS=>'form-control'])->label('Meta Tag');
        
    echo $form->field($model, 'seo_description', [TEMPLATE => FORM_TEMPLATE])
    ->textArea(['cols'=>3,'rows'=>5,'placeholder'=>'Meta Description'])->label('Meta Description');

?>