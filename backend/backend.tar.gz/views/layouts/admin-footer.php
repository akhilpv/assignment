<footer class="main-footer">
    <strong>Copyright © <?=date('Y')?> <a href=""><?=APP_NAME_FOOTER?></a>.</strong> All rights
    reserved.
  </footer>